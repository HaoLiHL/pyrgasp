# P_RobustGP
Python version of robust GP

## Installation
need install Python 3.7+, Pybind11, cppimport (see https://pybind11.readthedocs.io/en/latest/)
